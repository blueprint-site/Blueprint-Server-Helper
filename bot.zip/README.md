A bot that adds commands with a ?b prefix to add some fun and cool stuff to our server

# Not intended for public use
### This bot is tailor made for Blueprint's discord Server
If you intend to **copy and run** the bot in **your server** you need to change parameters such as but not limited to:
- guild ids
- user ids
- token

3rd party packages (asset store) are mentioned inside a TXT in assets

if u need help contact me by social media linked in my profile
